import React from 'react'
import Nava from "../components/Nava";
import Market  from '../components/Market';

function Favoritos() {
  return (
    <div>
      <div id='h1Titulo'>
        <h1>Perfil</h1>
      </div>
      <Market />
      <Nava />
    </div>
  )
}

export default Favoritos