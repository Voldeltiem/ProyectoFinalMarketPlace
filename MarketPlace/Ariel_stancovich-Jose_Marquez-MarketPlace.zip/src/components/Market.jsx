//donde se ven la publicaciones en miniatura
import React from 'react'
import Tarjeta from "./Tarjeta"

function Market() {
  return (
    <div id='market'>
      <Tarjeta/>
      <Tarjeta/>
      <Tarjeta/>
      <Tarjeta/>
      <Tarjeta/>
      <Tarjeta/>
    </div>
  )
}

export default Market