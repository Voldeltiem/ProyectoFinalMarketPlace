//seccion con publicidad 
import React from 'react'

function Section() {
  return (
    <div id="section">Section</div>
  )
}

export default Section