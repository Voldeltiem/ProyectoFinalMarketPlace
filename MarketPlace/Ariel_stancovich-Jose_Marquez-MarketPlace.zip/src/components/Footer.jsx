import React from 'react'

function Footer() {
  return (
    <div id='footer'>TodoMercado®</div>
  )
}

export default Footer